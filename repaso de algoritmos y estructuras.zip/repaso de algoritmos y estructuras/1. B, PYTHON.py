# Este codigo ha sido generado por el modulo psexport 20180802-w32 de PSeInt.
# Es posible que el codigo generado no sea completamente correcto. Si encuentra
# errores por favor reportelos en el foro (http://pseint.sourceforge.net).


if __name__ == '__main__':
	a = int()
	b = int()
	print("ingresa 2 numeros")
	a = int(input())
	b = int(input())
	if a==b:
		print("los numeros son iguales")
	else:
		if a>b:
			print("El numero ",a," es mayor")
		else:
			print("El numero",b," es mayor")

